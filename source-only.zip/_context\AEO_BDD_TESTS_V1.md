# 🧪 Behavior-Driven Development (BDD) Integration Tests

This document defines the business-logic integration tests in Given/When/Then format. These tests enforce the architectural constraints and tier boundaries defined in [AEO_BUSINESS_STRATEGY.md](file:///D:/MyApps/aeo-audit-tool-v3/_context/AEO_BUSINESS_STRATEGY.md) and [AEO_TOOL_MAPPING_V1.xlsx](file:///D:/MyApps/aeo-audit-tool-v3/_context/AEO_TOOL_MAPPING_V1.xlsx).

---

## Feature 1: Daily Scan Iteration Limits (Tries per Day)

### Scenario 1.1: AIVisualize Free Tier Daily Crawl Cap
  Given a user has an "AIVisualize Free" subscription plan
  And the user has already performed 5 scans today
  When the user submits a URL "https://example.com" for an AI Visualize scan
  Then the system intercept block blocks the scan request
  And the system does not increment the daily scan counter
  And the system returns a payload indicating execution limit has been reached
  And the frontend displays a modal UI window indicating an immediate upgrade trigger to AIVisualize Pro

### Scenario 1.2: AIOptimize Free Tier Daily Crawl Cap
  Given a user has an "AIOptimize Free" subscription plan
  And the user has already performed 5 scans today
  When the user submits a URL "https://example.com" for an AI Optimize scan
  Then the system intercept block blocks the scan request
  And the frontend displays a modal UI window indicating an immediate upgrade trigger to AIOptimize Pro

### Scenario 1.3: Pro Tier Scan Allocation Limit
  Given a user has an "AIVisualize Pro" subscription plan
  And the user has already performed 50 scans today
  When the user submits a URL "https://example.com" for an AI Visualize scan
  Then the system blocks the request and prompts an upgrade to Enterprise

---

## Feature 2: Scan Page Depth Budgets

### Scenario 2.1: AIVisualize Free Tier Page Depth Cap
  Given a user has an "AIVisualize Free" subscription plan
  When the user runs a scan on a domain with 10 total pages
  Then the crawler only processes a maximum of 3 pages
  And the scan output displays the content analyses of only those 3 pages
  And the scan output includes a count of the total number of pages (10 pages)

### Scenario 2.2: AIOptimize Free Tier Page Depth Cap
  Given a user has an "AIOptimize Free" subscription plan
  When the user runs an AI Optimize scan on a domain
  Then the system restricts the scan budget strictly to 1 Single Landing Page Profile
  And no secondary deep pages are crawled

### Scenario 2.3: AIVisualize Pro Tier Page Depth Cap
  Given a user has an "AIVisualize Pro" subscription plan
  When the user runs a scan on a domain with 50 pages
  Then the crawler processes a maximum of 40 pages
  And the remaining 10 pages are excluded from the scan results

---

## Feature 3: Headless Browser Runtime Allocations

### Scenario 3.1: AIVisualize Free and Pro Tier Headless Block
  Given a user is authenticated under "AIVisualize Free" or "AIVisualize Pro" or "AIOptimize Free"
  When the scan is executed on a user-submitted URL
  Then the backend uses programmatic text and DOM string-parsing (HTTP fetch/axios/cheerio)
  And the headless browser runtime session (Puppeteer/Playwright) is strictly disabled (0 sessions)

### Scenario 3.2: AIOptimize Pro Tier Headless Browser Caps
  Given a user has an "AIOptimize Pro" subscription plan
  And the user has already executed 3 headless browser sweeps today
  When the user requests an on-demand deep visual/CSS analysis sweep
  Then the system blocks the headless execution block
  And the system returns a notice prompting the user to upgrade to Enterprise or purchase metered add-on sweeps

### Scenario 3.3: Headless Sweeps Timeout Guardrail
  Given a user is on a paid tier with headless sweep sessions available ("AIOptimize Pro" or "AIOptimize ENT")
  When the user triggers an on-demand headless browser sweep
  Then the system executes the sweep across the allowed web directory path in a single synchronous loop
  And the system monitors the execution with a strict timeout limit to prevent ghost zombie processes
  And the session object is systematically terminated when the timeout is reached or the sweep completes

---

## Feature 4: Cloudflare Worker Edge Integration Sandbox

### Scenario 4.1: Edge Code Generation Sandbox Isolation
  Given a user is in the AIOptimize Pro dashboard trying to optimize a locked Shopify CMS site
  When the user selects "Shopify / Cloudflare Edge Workaround Track" in the target dropdown
  Then the platform does not attempt to authenticate with Cloudflare
  And the platform does not push or write files to any live Cloudflare account
  And the workspace UI generates a raw text display viewport containing a custom Cloudflare Worker script template
  And the UI renders a "Click to Copy" button asset for manual user clipboard copy

---

## Feature 5: Protocol Gates & Robots.txt Disallow Check

### Scenario 5.1: Critical Disallow Alert
  Given a user executes an AI Visualize scan on a domain
  And the domain's robots.txt contains "User-agent: *" followed by "Disallow: /"
  When the scan processes the Robots.txt protocol gate
  Then the system flags a "TOTAL AI BLINDNESS" critical alert status
  And the report marks the domain visibility score as "Ugly" (FAIL)
  And the dashboard displays a call-to-action redirecting to the AIOptimize Workspace upgrade hook to download the corrected robots.txt permission split

---

## Feature 6: Affiliate Network Referral Gating

### Scenario 6.1: External AI Citation Tracking Redirect
  Given a user is viewing the "AI Visibility Tracking & Share of Voice" dashboard component
  When the user attempts to view live brand citation percentages or track keywords across ChatGPT, Claude, and Perplexity
  Then the component displays a Call-to-Action block detailing the affiliate tracking network
  And the user-accessible link routes the user externally via an affiliate tracking URL directly to partner platform suites (e.g., Semrush's Generative AI Engine Tracking utilities)
  And the application does not execute local scraper checks for live search engine share-of-voice data

---

## Feature 7: End-to-End Vitest Regression Suite

### Scenario 7.1: Comprehensive Backend Endpoint and Module Test Coverage
  Given the full application codebase across Sprints 1 through 8
  When the automated Vitest test runner is executed against all service modules (`crawlerService.js`, `parserService.js`, `generatorService.js`, `authController.js`, `rateLimiter.js`)
  Then all unit and integration test assertions pass cleanly with 0 failures
  And all 32 core capabilities and quota boundaries function without backward regression

---

## Feature 8: Twelve-Factor Staging Deployment Pre-Flight

### Scenario 8.1: Environment Variable and Pre-Flight Staging Audit
  Given the digital staging environment configuration for DigitalOcean App Platform (`.do/app.yaml`)
  When the deployment validator inspects environment variables (`PORT`, `MONGO_URI`, `JWT_SECRET`, `NODE_ENV`, `RATE_LIMIT_FREE_DAILY`)
  Then all required 12-factor environment keys are validated
  And the staging pre-flight checklist (`DIGITALOCEAN_STAGING_DEPLOYMENT_GUIDE.md`) is verified ready for zero-downtime container launch

---

## Feature 9: Landing Page Console Tab Switcher Display, Alignment, Visual Text Presence & Mobile Responsiveness

### Scenario 9.1: Console Tab Switcher Display and 3-Column Desktop Alignment
  Given a user visits the Thatworkx AEO Suite landing page on a desktop device (viewport width >= 768px)
  When the Hero section search console card is rendered
  Then the console tab switcher container displays three distinct product tab switcher buttons: "AI Visualize", "AIOptimize", and "AISocialize"
  And the tab buttons are aligned side-by-side in a 3-column grid container (`grid grid-cols-1 md:grid-cols-3 gap-4`)
  And each tab button maintains equal card proportions, padding, and uniform height constraints (`min-height-[280px]`)

### Scenario 9.2: Visual Text Presence and Branding Content Verification
  Given the console tab switcher buttons are rendered on the landing page
  When inspecting the visual text and iconography elements of each switcher button
  Then the "AI Visualize" tab button displays:
    - Title: "Eye Icon" + "AI Visualize" (or "👁️ AI Visualize")
    - Subhead: "Let show you what AI can see."
    - Feature List:
      1. "1. Are you blocking out AI?"
      2. "2. Is your web presence optimized for AI?"
      3. "3. Is your content AI-Ready?"
      4. "4. Are you setup to be AI-First?"
  And the "AIOptimize" tab button displays:
    - Title: "ShieldAlert Icon" + "AIOptimize" (or "🩺 AIOptimize")
    - Subhead: "IF you already know that you are AI-ready, lets show you how to be Optimized for AI."
    - Feature List:
      1. "• Optimizing for AI-Ready"
      2. "• Optimizing for AI-First"
  And the "AISocialize" tab button displays:
    - Title: "Share2 Icon" + "AISocialize" (or "📣 AISocialize")
    - Subhead: "Go further, ensure your social footprint is Optimized for AI"
    - Section Headers & Sublists:
      1. "Is your domain AI-ready for social?" ("- llms.txt exists", "- Has Author Info", "- Credential mentions", "- External links(Valid)", "- Authority links(valid)", "- LastUpdated")
      2. "Elevate your Social to AI-Ready"

### Scenario 9.3: Interactive Active State Selection and Visual Accent Theme Styling
  Given the console tab switcher is rendered with "AI Visualize" active by default
  When the user clicks or selects a tab button ("AIOptimize" or "AISocialize")
  Then the active tab button receives an elevated background and distinct theme accent border:
    | Tab Button | Brand Accent | Border Styling | Icon Accent Class |
    | AI Visualize | Cyan | `border-cyan-500/60` | `text-cyan-400` / `text-cyan` |
    | AIOptimize | Amber | `border-amber-500/60` | `text-amber-400` / `text-amber` |
    | AISocialize | Violet | `border-violet-500/60` | `text-violet-400` / `text-violet` |
  And non-active tab buttons revert to transparent border styling (`border-transparent`)
  And the main input form placeholder text, action button text, and accent colors dynamically update to reflect the chosen product mode
  And selecting "AISocialize" renders the extension dependency notice: "⚡ Chrome Extension Required for Snippet Generation [Install Extension]"

### Scenario 9.4: Mobile Responsiveness and Adaptive Single-Column Stacking
  Given a user accesses the landing page on a mobile device (viewport width < 768px)
  When the Hero section console card is rendered
  Then the 3-column tab container automatically transitions into a single-column stacked layout (`grid-cols-1`)
  And each tab button expands to 100% full container width without horizontal scrolling or element truncation
  And all text nodes (titles, subheads, list items) maintain responsive, legible typography (`text-lg`, `text-xs`, `text-[11px]`)
  And touch target areas for each tab button meet mobile accessibility guidelines (minimum target height >= 44px)

---

## Feature 10: 4-Page Architecture, Deep-Linked URL Search Parameters & REST API Readiness

### Scenario 10.1: Direct URL Audit Triggers (`visualize.html?url=example.com`)
  Given a user accesses `visualize.html?url=example.com`
  When the page initializes
  Then the AIVisualize scanner automatically executes or fetches audit metrics for `example.com`
  And the top scanned route header displays `example.com`
  And all 32 capability metric cards populate cleanly without requiring manual search bar entry.

### Scenario 10.2: Deep-Linked View Mode Triggers (`visualize.html?url=example.com&mode=developer`)
  Given a user accesses `visualize.html?url=example.com&mode=developer`
  When the AIVisualize page finishes loading
  Then the Developer / DIY Mode view is active by default
  And the 32-capability diagnostic matrix and machine code drawers are displayed
  And when `mode=executive` is specified, Executive Mode is active showing the score dial gauge and perception simulator.

### Scenario 10.3: Deep-Linked Target Domain on AIOptimize (`optimize.html?url=example.com`)
  Given a user navigates to `optimize.html?url=example.com`
  When the AIOptimize page initializes
  Then the target domain input is pre-filled with `example.com`
  And remediation generators (Track 1 Page Fixes & Track 2 File Generators) load configured manifests for `example.com`.

### Scenario 10.4: Programmatic REST API Audit Endpoints (`/api/v1/scan?url=example.com`)
  Given a Pro or Enterprise API consumer issues a request to `GET /api/v1/scan?url=example.com` or `POST /api/v1/scan`
  When valid authorization credentials or session tokens are provided
  Then the system returns a structured JSON payload containing the 32-capability diagnostic evaluation matrix, score health index, and generated machine manifest paths
  And the API response supports headless sweep flags (`headless=true`) for authorized Pro/ENT accounts.

### Scenario 10.5: Global Auth Modal & Navigation Bar Integrity across 4 Pages
  Given a user is navigating across any of the 4 dedicated pages (`index.html`, `visualize.html`, `optimize.html`, `socialize.html`)
  When the user clicks "🔑 Sign In" in the top navigation header
  Then the authentication OTP modal opens cleanly over the active page
  And the top header brand logo (`THATWORKX AEO SUITE`) provides a clean hyperlink returning to `index.html`.



